//tipos primitivos

//boolean - true or false
var tOuF = false;
console.log(typeof(tOuF));

//number
var num = 1;
console.log(typeof(num));

//string
var nome = "henrique";
console.log(typeof(nome));

//declarando variaveis, VAR, LET OU CONST
//var - escopo global e local, pode ter seu valor alterado, se nao tiver um valor inicial e tratada como null
var variavel = 'pacheco';
variavel = 'da luz'; //alterando o valor da variavel
console.log(variavel);

//let - escopo local de bloco, pode ter seu valor alterado, se nao tiver um valor inicial e tratada como null
let variavel2 = 'oi';
variavel = 'ola';
console.log(variavel2);

//const - escopo local de bloco, somente leitura, o valor inicial e obrigatorio e nao pode ser alterado
const constante = 1;
console.log(constante);

//escopos
//global - quando a variavel e declarada fora de qualquer bloco, sua visibilidade fica disponivel em todo o codigo
//local - quando a variavel e declarada dentro de um bloco, sua visibilidade pode ficar disponivel ou nao
var escopoGlobal = 'global';
console.log(escopoGlobal);

function escopoLocal(){
    let escopoLocalInterno = 'local';
    console.log(escopoLocalInterno);
}

escopoLocal();

//comparacao identica, compara os valores e os tipos da variavel
var compIdentica = 'teste' === 0;
console.log(compIdentica);



