// arrays ou vetores []
// e um tipo de lista, ou matriz de variaveis, onde cada variavel possui um indice, os valores podem ser de varios tipos
let array = ['string', 1, true];
console.log(array);

let array2 = ['string', 1, true, ['array3'], ['array4'], ['array5']];
console.log(array2[2]);

// manipulando arrays
// forEach() - intera um array
array.forEach(function(item, index){console.log(item, index)});

// push() - adiciona um item no final do array
array.push('novoitemfinal');
console.log(array);

// pop() - remove um item no final do array
array.pop();
console.log(array);

// shift() - remove um item no inicio do array
array.shift();
console.log(array);

// unshift() - adicional um item no inicio do array
array.unshift('novoiteminicio');
console.log(array);

// indexOf() - retorna o index de um valor
console.log(array.indexOf(true));

// splice() - remove ou substitui um item pelo indice
array.splice(0, 2);
console.log(array);

// slice() - retorna uma parte de um array existente
let novoArray = array.slice(0, 3);
console.log(novoArray);

// objetos
let object = {string: 'string', number: 1, boolean: true, array: ['array'], objectInterno: {objectiInterno: 'objeto interno'}};
console.log(object.number);

// desestruturacao do objeto
// stringInterna e arrayInterno vai receber os valores que estao dentro de string/array do object respectivamente
var stringInterna = object.string;
console.log(stringInterna);

var arrayInterno = object.array;
console.log(arrayInterno);

// recebe o object inteiro e filtra o quer vai ser retornado, nesse caso, string, number e boolean
var {string, number, boolean} = object;
console.log(string, number, boolean);




