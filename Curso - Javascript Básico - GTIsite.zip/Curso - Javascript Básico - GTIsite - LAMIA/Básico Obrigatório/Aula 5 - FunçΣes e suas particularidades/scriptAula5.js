// funcoes
function funcao(){
    console.log("Teste de função.");
}
funcao();

// funcoes com parametros
function mensagem(primeiro, segundo){
    console.log(primeiro, segundo);
}
mensagem("Teste de função", "2.");