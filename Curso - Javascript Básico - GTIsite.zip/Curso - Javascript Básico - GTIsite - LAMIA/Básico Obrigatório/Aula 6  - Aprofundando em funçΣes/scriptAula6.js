//tipos de funcoes
//declarativas
function funcao(){
    console.log("Função declarativa.");
}
funcao();

//expressao de funcao, COM nomeacao
var funcao = function funcao(){
    console.log("Função expressao com nomeação.");
}
funcao();

//expressao de funcao, SEM nomeacao
var funcao = function(){
    console.log("Função expressao sem nomeação.");
}
funcao();

//arrow function
var funcao = () =>{
    console.log("Função Arrow Function.");
}
funcao();

