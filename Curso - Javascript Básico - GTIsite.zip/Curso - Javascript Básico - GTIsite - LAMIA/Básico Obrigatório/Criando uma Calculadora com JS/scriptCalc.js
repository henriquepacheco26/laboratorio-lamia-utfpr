//funcao principal - calculadora
function calculadora(){

    //"menu" da calculadora, transformando o tipo para numero
    const operacao = Number(prompt("Escolha uma operação: \n 1 - Soma(+) \n 2 - Subtração(-) \n 3 - Multiplicação(*) \n 4 - Divisão Real(/) \n 5 - Divisão Inteira(%) \n 6 - Potenciação(**)"));
    console.log(operacao);

    //condicao para a calculadora nao aceitar numeros fora da operacao
    if(!operacao || operacao >= 7){
        alert("Erro - Operação inválida.");
        calculadora();
    
    //pedindo valores ao usuario, ja transformados para numero
    } else {
    let n1 = Number(prompt("Insira o primeiro valor: "));
    let n2 = Number(prompt("Insira o segundo valor: "));
    let resultado;
    
    //verifacacao se os valores passados forem diferentes de numeros, gera um erro
    if(!n1 || !n2){
        alert("Erro - Paramêtros inválidos.");
        calculadora();
    } else {
    
    //todas as funcoes de operacao da calculadora, soma, subtracao... etc
    function soma(){
        resultado = n1 + n2;
        alert(`${n1} + ${n2} = ${resultado}`);
        novaOperacao();
    }

    function sub(){
        resultado = n1 - n2;
        alert(`${n1} - ${n2} = ${resultado}`);
        novaOperacao();
    }

    function multi(){
        resultado = n1 * n2;
        alert(`${n1} * ${n2} = ${resultado}`);
        novaOperacao();
    }

    function divReal(){
        resultado = n1 / n2;
        alert(`${n1} / ${n2} = ${resultado}`);
        novaOperacao();
    }

    function divInt(){
        resultado = n1 % n2;
        alert(`O resto da divisão de ${n1} e ${n2} é = ${resultado}`);
        novaOperacao();
    }

    function poten(){
        resultado = n1 ** n2;
        alert(`${n1} elevado a ${n2} é = ${resultado}`);
        novaOperacao();
    }

    function novaOperacao(){
        let opcao = prompt("Deseja fazer uma nova operação? \n 1 - Sim \n 2 - Não");

        if(opcao == 1){
            calculadora();
        } else if(opcao == 2){
            alert("Até mais.");
        } else {
            alert("Digite uma opção válida: ");
            novaOperacao();
        }
    }
}

    //condicao para entrar na operacao correta, se o usuario digitar 1, entra na soma, assim sucessivamente
    if(operacao == 1){
        soma();
    } else if(operacao == 2){
        sub();
    } else if(operacao == 3){
        multi();
    } else if(operacao == 4){
        divReal();
    }  else if(operacao == 5){
        divInt();
    } else if(operacao == 6){
        poten();
    }  
  }
}

//chamando/executando a funcao calculadora
calculadora();