//array
var lista = ["maça", "pera", "laranja", "banana"];
lista.push("uva"); //adiciona um elemento na lista
lista.pop(); //retira um elemento da lista, nesse caso a uva
console.log(lista);

//length - tamanho da lista, quantidade de elementos do array
console.log(lista.length);

//reverse - imprimi os elementos ao contrario
console.log(lista.reverse());

//toString - transforma o array numa string
console.log(lista.toString());

//join - transforma o array numa string e permite adicionar espaços, traços, outras strings, etc
console.log(lista.join(" - "));

//dicionario
var frutas = [{nome: "maça", cor: "vermelha"}, {nome: "uva", cor: "verde"}];
console.log(frutas);
console.log(frutas[1].cor); //mostrando a cor da fruta do dicionario 1, no caso verde