//condicionais
var idade = prompt("Qual a sua idade? "); //prompt - usuario digita um valor
if(idade >= 18){
    alert("Maior de idade.");
} else {
    alert("Menor de idade.");
}

//laços de repetição

//while
var count = 0;
while(count <= 5){
    //console.log(count);
    count++;
}

//for
var count;
for(count=0; count <=5; count++){
    console.log(count);
}

//date
var d = new Date(); //mostra o data do dia de hoje, com dia, mes, ano e horario
console.log(d);
console.log(d.getMonth()+1); //mostrando apenas o mes
console.log(d.getHours()); //mostrando apenas a hora (os dois primeiros numeros)
console.log(d.getMinutes()); //mostrando apenas os minutos da hora (os dois ultimos numeros)
console.log(d.getDate()); //mostrando apenas o dia