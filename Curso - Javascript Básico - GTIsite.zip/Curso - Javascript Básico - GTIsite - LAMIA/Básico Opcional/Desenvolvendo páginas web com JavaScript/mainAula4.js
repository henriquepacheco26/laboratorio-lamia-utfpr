//funções

//somar dois valores
function soma(n1,n2){
    return n1 + n2;
}
alert(soma(5, 10));

//validar a idade, se for maior ou igual a 18, é true, caso contrario else
//com variavel local
function validaIdade(idade){
    var validar;
    if(idade >= 18){
        validar = true;
    } else {
        validar = false;
    }
    return validar;
}
var idade = prompt("Qual a sua idade? ");
console.log(validaIdade(idade));
