//variavel concatenada
var nome = "Henrique Pacheco";
var idade = 20;
//alert(nome + " tem " + idade + " anos. ");

//console.log
var frase = "São Paulo é o melhor time do brasil."
console.log(nome);
console.log(idade);
console.log(frase.replace("brasil", "mundo")); //.replace troca uma palavra pela outra, troquei brasil por mundo
console.log(frase.toLocaleUpperCase()); //deixa a frase inteira em letras maiusculas
console.log(frase.toLocaleLowerCase()); //deixa a frase inteira em letras minusculas

//.replace no alert
alert(frase.replace("brasil", "mundo"));