//funções

//função de mensagem para quando a pessoa clicar no botao
function clicou(){
    document.getElementById("obrigado por clicar.");
    document.getElementById("obrigado por clicar.").innerHTML = "Obrigado por clicar."; //gerando um h3 no html ao clicar no botao com o texto passado
    console.log(document.getElementById("obrigado por clicar.")); //imprimindo o h3 com o id no console
    alert("Obrigado por clicar."); //gerando um alert ao clicar no botao
}

//função para redirecionar o usuario para outra pagina ao clicar no texto h3 do html ('obrigado por clicar')
function redirecionar(){
    //link abre numa nova aba
    window.open("https://trello.com/b/AAy0F4L4/gti02-2019-site-lamia");

    //outra maneira de redirecionar - dessa forma o link abre na mesma guia
    //window.location.href = "https://trello.com/b/AAy0F4L4/gti02-2019-site-lamia";
}

//função para trocar o texto ao passar o mouse por cima do h4, trocando "passe o mouse aqui" por "obrigado por passar o mouse"
function trocar(elemento){
    elemento.innerHTML = "Obrigado por passar o mouse.";
}

//função para voltar o texto, volta de "obrigado por passar o mouse" para "passe o mouse aqui" novamente
function voltar(elemento){
    elemento.innerHTML = "Passe o mouse aqui.";
}

//função que ao carregar a pagina gera um alert
function load(){
    alert("Página carregada.");
}

//função que ao clicar no 'menu' criado no html, ele mostra o valor do elemento 'value' no console
function change(elemento){
    console.log(elemento.value);
}