#importando as bibliotecas
from logging import exception #essa foi automático
import psycopg2 as db
import csv

#criando class de configuração do banco(passando dados do banco, como usuario, senha etc)
class Config:
    def __init__(self):
        self.config = {
            "postgres": {
                "user": "postgres",
                "password": "postgres",
                "host": "127.0.0.1",
                "port": "5432",
                "database": "pydb"
            }

        }

#criando class de conexão do banco com python, pegando o nome do database do postgre
class Connection(Config):
    def __init__(self):
        Config.__init__(self)
        try:
            self.conn = db.connect(**self.config["postgres"])
            self.cur = self.conn.cursor()
        except exception as e:
            print("Erro na conexão", e)
            exit(1)


    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.commit()
        self.connection.close()

    
    @property
    def connection(self):
        return self.conn

    @property
    def cursor(self):
        return self.cur

    def commit(self):
        self.connection.commit()

    def fetchall(self):
        return self.cursor.fetchall()

    def execute(self, sql, params=None):
        self.cursor.execute(sql, params or ())

    def query(self, sql, params=None):
        self.cursor.execute(sql, params or ())
        return self.fetchall()


#class conectando o person com python
class Person(Connection):
    def __init__(self):
        Connection.__init__(self)

    #def para inserir os dados no banco
    def insert(self, *args):
        try:
            sql = "INSERT INTO person (name) VALUES (%s)"
            self.execute(sql, args)
            self.commit()
        except exception as e:
            print("Erro ao inserir", e)

    #def para inserir os dados no banco apartir do arquivo csv
    def insert_csv(self, filename):
        try:
            data = csv.DictReader(open(filename, encoding="utf-8"))
            for row in data:
                self.insert(row["name"])
            print("Registro Inserido")
        except exception as e:
            print("Erro ao inserir", e)

    #def para deletar dados do banco
    def delete(self, id):
        try:
            sql_s = f"SELECT * FROM person WHERE id = {id}"
            if not self.query(sql_s):
                return "Registro não encontrado para deletar"
            sql_d = f"DELETE FROM person WHERE id = {id}"
            self.execute(sql_d)
            self.commit()
            return "Registro deletado"
        except exception as e:
            print("Erro ao deletar", e)

    #def para atualizar dados do banco
    def update(self, id, *args):
        try:
            sql = f"UPDATE person SET name = %s WHERE id = {id}"
            self.execute(sql, args)
            self.commit()
            print("Registro atualizado")
        except exception as e:
            print("Erro ao atualizar", e)

    #def para pesquisar dados no banco
    def search(self, *args, type_s="name"):
        sql = "SELECT * FROM person WHERE name LIKE %s"
        if type_s == "id":
            sql = "SELECT * FROM person WHERE id = %s"
        data = self.query(sql, args)
        if data:
            return data
        return "Registro não encontrado"



#rodando o codigo
if __name__ == "__main__":
    person = Person()
    print(person.query("SELECT * FROM person"))

    #person.insert("Maria")
    person.insert_csv("data.csv")

    #print(person.delete(6))

    #person.update(1, "Maria José")

    #print(person.search(2, type_s="id"))

    #print(person.search("%José%"))

    #x = input("Pesquisar por: ")
    #x = f"%{x}%"
    #print(person.search(x))


    #print(person.query("SELECT * FROM person"))


    