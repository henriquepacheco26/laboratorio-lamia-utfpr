-- MiniCurso Dbeaver - C�digosGerados - HenriquePacheco

-- exibir o banco de dados completo (todas as colunas)
select *
from dataset_1 d;

-- exibir colunas especificas do banco 
select destination, passanger
from dataset_1 d;

-- limitar o numero de linhas
select destination, passanger
from dataset_1 d
limit 10;

-- mostrar os valores unicos/exclusivos de uma coluna 
select DISTINCT passanger 
from dataset_1 d;

-- fun��o ONDE (WHERE), mostrar onde A � igual a B
select *
from dataset_1 d 
where passanger = 'Alone';

-- fun��o E (AND), adiciona mais condi��es pra filtrar os dados 
select *
from dataset_1 d 
where passanger = 'Alone'
and weather = 'Snowy'
and gender = 'Male';

-- fun��o OU (OR), temos duas op��es, OU os dados apareceram sobre A OU sobre B
select *
from dataset_1 d 
where passanger = 'Alone'
or time = '2PM';

-- fun��o ORDENAR POR (ORDEM BY), classifica o banco de acordo com o parametro passado
-- ASC (1,2,3,4,5),  DESC(9,8,7,6,5)
select *
from dataset_1 d 
where passanger = 'Alone'
or time = '2PM'
order by time DESC;

-- fun��o Aliasing, altera o nome das colunas
select destination , passanger , time as 'The Time'
from dataset_1 d 
where passanger = 'Alone'
or time = '2PM'
order by time DESC;

-- fun��o AGRUPAR POR (GROUP BY), agrupa os dados por certas colunas
-- AVG = m�dia
-- SUM = soma
-- COUNT = contar os registros
select destination, AVG(temperature), SUM(temperature), COUNT(temperature)
from dataset_1 d 
group by destination;

-- m�dia de temperatura por horario
select destination, time, AVG(temperature)
from dataset_1 d 
group by destination, time;

-- filtro avan�ado das colunas, 
-- no exemplo, filtrar pelas horas (PM), s� mostra as colunas que tem PM
select *
from dataset_1 d
where time like '%P%';

-- fun��o ENTRE (BETWEEN), mostra valores entre um numero e outro
select destination, temperature 
from dataset_1 d 
where temperature BETWEEN 30 and 80
limit 50;

-- fun��o NUMERO DA LINHA (ROW_NUMBER), mostra/determina o numero de cada linha,
-- criando uma nova coluna
select destination, weather,
row_number() over (partition by weather order by destination) 
from dataset_1 d 
limit 50;

